package com.caiozero.githubtrendingrepos.activity;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;

import com.caiozero.githubtrendingrepos.R;
import com.caiozero.githubtrendingrepos.api.GitService;
import com.caiozero.githubtrendingrepos.models.Trending;

import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class MainActivity extends AppCompatActivity {

    public static final String Tag = "GIT_ERRO";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl(GitService.Base_Url)
                .addConverterFactory(GsonConverterFactory.create())
                .build();

        /*Create Class to receive Gson Object*/
        GitService service = retrofit.create(GitService.class);
        Call<List<Trending>> requestGitApi = service.listTrending();


        /*Async Callback*/
        requestGitApi.enqueue(new Callback<List<Trending>>() {
            @Override
            public void onResponse(Call<List<Trending>> call, Response<List<Trending>> response) {
                if (!response.isSuccessful()) {
                    Log.e(Tag, "Erro IS SUCESSFULL " + response.code());
                } else {
                    /*Request Successful*/
                       List<Trending> trendingList = response.body();
                       for(Trending t: trendingList){
                         Log.i(Tag, t.getAuthor().toString());
                         Log.i(Tag, t.getName().toString());
                         Log.i(Tag, t.getStars().toString());
                         Log.i(Tag, t.getForks().toString());
                         Log.i(Tag, "-------------------");
                    }
                }

            }

            /*When request gets an error*/
            @Override
            public void onFailure(Call<List<Trending>>call, Throwable t) {
                Log.e(Tag,"Erro REQUEST ON FAILURE "+t.getMessage());
            }
        });
    }
}


/*Built by - Instructor
* Trending = Course
* GItRepo = UdacityCatalog
* GitService = UdacityService
* gitAPIservice = service
* requestGitApi = requestCatalog*/