package com.caiozero.githubtrendingrepos.activity;
import android.app.*;

public class RepoDetails {
    public class View
}
